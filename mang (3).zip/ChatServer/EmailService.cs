using System.Net;
using System.Net.Mail;

namespace ChatServer;

public sealed class EmailService
{
    private readonly string _username;
    private readonly string _appPassword;

    public EmailService(IReadOnlyDictionary<string, string> config)
    {
        _username = config.GetValueOrDefault("EMAIL_USER", "");
        _appPassword = config.GetValueOrDefault("EMAIL_APP_PASSWORD", "").Replace(" ", "", StringComparison.Ordinal);
    }

    public bool IsConfigured => _username.Length > 0 && _appPassword.Length > 0;

    public async Task SendOtpAsync(string recipient, string otp)
    {
        if (!IsConfigured)
            throw new InvalidOperationException("Server chua cau hinh EMAIL_USER va EMAIL_APP_PASSWORD trong .env.");

        using var message = new MailMessage(_username, recipient)
        {
            Subject = "RE:CHAT - Ma xac nhan bao mat",
            Body = $"Ma OTP cua ban la: {otp}\n\nMa co hieu luc trong 10 phut. Neu ban khong yeu cau thay doi bao mat, hay bo qua email nay."
        };
        using var smtp = new SmtpClient("smtp.gmail.com", 587)
        {
            EnableSsl = true,
            Credentials = new NetworkCredential(_username, _appPassword)
        };
        await smtp.SendMailAsync(message);
    }
}
