using System.Net;
using System.Net.Mail;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using ChatProtocol;
using QRCoder;

namespace ChatServer;

public static class Program
{
    // Danh sach phong mac dinh
    private static readonly string[] DefaultRooms = { "General", "Random", "Tech" };
    private static readonly RoomManager Rooms = new(DefaultRooms);
    private static readonly List<ClientSession> AllClients = new();
    private static readonly object AllClientsLock = new();
    private static MongoUserStore? UserStore;
    private static MongoMessageStore? MessageStore;
    private static MongoDirectMessageStore? DirectMessageStore;
    private static AiService Ai = new(null);
    private static EmailService Email = null!;
    private static OtpJwtService OtpTokens = null!;

    public static async Task Main(string[] args)
    {
        var config = EnvironmentConfig.Load();
        Email = new EmailService(config);
        OtpTokens = new OtpJwtService(config.GetValueOrDefault("JWT_SECRET", ""));
        if (config.TryGetValue("MONGODB_URI", out var mongoUri) && mongoUri.Length > 0)
        {
            try
            {
                var mongo = new MongoContext(mongoUri);

                UserStore = new MongoUserStore(mongo.Database);
                await UserStore.InitializeAsync();

                MessageStore = new MongoMessageStore(mongo.Database);
                await MessageStore.InitializeAsync();

                DirectMessageStore = new MongoDirectMessageStore(mongo.Database);
                await DirectMessageStore.InitializeAsync();

                Console.WriteLine($"[ChatServer] Đã kết nối MongoDB tại URI: {mongoUri}");
                Console.WriteLine($"[ChatServer] Tên cơ sở dữ liệu: {mongo.Database.DatabaseNamespace.DatabaseName}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[ChatServer] Khong ket noi duoc MongoDB: {ex.Message}");
            }
        }
        else
        {
            Console.WriteLine("[ChatServer] Thieu MONGODB_URI trong .env.");
        }

        config.TryGetValue("AI_SERVICE_URL", out var aiServiceUrl);
        Ai = new AiService(aiServiceUrl);

        int port = config.TryGetValue("PORT", out var configuredPort) && int.TryParse(configuredPort, out var envPort)
            ? envPort
            : 5050;
        if (args.Length > 0 && int.TryParse(args[0], out var p)) port = p;

        var listener = new TcpListener(IPAddress.Any, port);
        listener.Start();
        Console.WriteLine($"[ChatServer] Dang lang nghe TCP tai cong {port} (giao thuc length-prefix JSON) ...");
        Console.WriteLine($"[ChatServer] Phong mac dinh: {string.Join(", ", DefaultRooms)}");

        while (true)
        {
            TcpClient tcpClient = await listener.AcceptTcpClientAsync();
            var session = new ClientSession(tcpClient);
            lock (AllClientsLock) AllClients.Add(session);

            // Moi client duoc xu ly tren 1 Task rieng -> server phuc vu nhieu client dong thoi
            _ = Task.Run(() => HandleClientAsync(session));
        }
    }

    private static async Task HandleClientAsync(ClientSession session)
    {
        var remoteEp = session.TcpClient.Client.RemoteEndPoint;
        Console.WriteLine($"[+] Ket noi moi tu {remoteEp}");

        try
        {
            while (true)
            {
                Envelope? envelope;
                try
                {
                    envelope = await FrameCodec.ReadAsync(session.Stream);
                }
                catch (InvalidDataException ex)
                {
                    Console.WriteLine($"[!] Frame khong hop le tu {remoteEp}: {ex.Message}");
                    break;
                }
                if (envelope == null) break; // client dong ket noi

                await DispatchAsync(session, envelope);
            }
        }
        catch (IOException)
        {
            // Client rot mang dot ngot -> coi nhu disconnect binh thuong
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[!] Loi voi client {remoteEp}: {ex.Message}");
        }
        finally
        {
            await HandleDisconnectAsync(session);
        }
    }

    private static async Task DispatchAsync(ClientSession session, Envelope envelope)
    {
        switch (envelope.Type)
        {
            case "join":
                await HandleJoinAsync(session, envelope.As<JoinRequest>());
                break;

            case "register":
                await HandleRegisterRequestAsync(session, envelope.As<RegisterRequest>());
                break;

            case "register-verify":
                await HandleRegisterVerifyAsync(session, envelope.As<VerifyRegistrationRequest>());
                break;

            case "login":
                await HandleLoginAsync(session, envelope.As<AuthRequest>());
                break;

            case "2fa-verify":
                await HandleTwoFactorVerifyAsync(session, envelope.As<TwoFactorVerifyRequest>());
                break;

            case "request-password-reset-otp":
                await HandleRequestPasswordResetOtpAsync(session, envelope.As<RequestPasswordResetOtp>());
                break;

            case "verify-password-reset":
                await HandleVerifyPasswordResetAsync(session, envelope.As<VerifyPasswordResetRequest>());
                break;

            case "profile":
                await HandleProfileAsync(session, envelope.As<ProfileRequest>());
                break;

            case "request-password-change-otp":
                await HandleRequestPasswordChangeOtpAsync(session);
                break;

            case "verify-password-change":
                await HandleVerifyPasswordChangeAsync(session, envelope.As<VerifyPasswordChangeRequest>());
                break;

            case "update-avatar":
                await HandleUpdateAvatarAsync(session, envelope.As<UpdateAvatarRequest>());
                break;

            case "update-profile":
                await HandleUpdateProfileAsync(session, envelope.As<UpdateProfileRequest>());
                break;

            case "update-privacy":
                await HandleUpdatePrivacyAsync(session, envelope.As<UpdatePrivacyRequest>());
                break;

            case "block-user":
                await HandleBlockUserAsync(session, envelope.As<BlockUserRequest>());
                break;

            case "update-appearance":
                await HandleUpdateAppearanceAsync(session, envelope.As<UpdateAppearanceRequest>());
                break;

            case "create-room":
                await HandleCreateRoomAsync(session, envelope.As<CreateRoomRequest>());
                break;

            case "chat":
                await HandleChatAsync(session, envelope.As<ChatRequest>());
                break;

            case "typing":
                await HandleTypingAsync(session, envelope.As<TypingRequest>());
                break;

            case "direct-message":
                await HandleDirectMessageAsync(session, envelope.As<DirectMessageRequest>());
                break;

            case "get-unread-direct-messages":
                await HandleGetUnreadDirectMessagesAsync(session);
                break;

            // Session management
            case "get-sessions":
                await HandleGetSessionsAsync(session);
                break;

            case "revoke-session":
                await HandleRevokeSessionAsync(session, envelope.As<RevokeSessionRequest>());
                break;

            case "revoke-all-sessions":
                await HandleRevokeAllSessionsAsync(session);
                break;

            // Two-factor authentication
            case "2fa-setup":
                await HandleTwoFactorSetupAsync(session);
                break;

            case "2fa-enable":
                await HandleTwoFactorEnableAsync(session, envelope.As<TwoFactorEnableRequest>());
                break;

            case "2fa-disable":
                await HandleTwoFactorDisableAsync(session, envelope.As<TwoFactorDisableRequest>());
                break;

            case "2fa-status":
                await HandleTwoFactorStatusAsync(session);
                break;

            // Login history
            case "get-login-history":
                await HandleGetLoginHistoryAsync(session);
                break;

            default:
                await session.SendAsync("error", new ErrorResponse($"Loai message khong hop le: {envelope.Type}"));
                break;
        }
    }

    private static async Task HandleProfileAsync(ClientSession session, ProfileRequest? req)
    {
        if (!session.IsAuthenticated || UserStore == null) return;

        var username = (req?.Username ?? session.Username).Trim();
        var profile = await UserStore.GetProfileAsync(username, IsUserOnline(username));
        await session.SendAsync("profile", new ProfileResponse(profile));
    }

    private static async Task HandleRequestPasswordResetOtpAsync(ClientSession session, RequestPasswordResetOtp? req)
    {
        if (UserStore == null)
        {
            await session.SendAsync("error", new ErrorResponse("MongoDB chua san sang."));
            return;
        }
        if (req == null || !req.Email.Contains('@'))
        {
            await session.SendAsync("error", new ErrorResponse("Email khong hop le."));
            return;
        }

        var email = req.Email.Trim();
        var username = await UserStore.GetUsernameByEmailAsync(email);
        if (username == null)
        {
            await session.SendAsync("error", new ErrorResponse("Email chua duoc dang ky trong he thong."));
            return;
        }
        if (!Email.IsConfigured)
        {
            await session.SendAsync("error", new ErrorResponse("Server chua cau hinh EMAIL_USER va EMAIL_APP_PASSWORD."));
            return;
        }

        var otp = RandomNumberGenerator.GetInt32(100000, 1000000).ToString();
        try
        {
            await Email.SendOtpAsync(email, otp);
            session.PendingPasswordResetToken = OtpTokens.Create(username, email, otp, DateTime.UtcNow.AddMinutes(10));
            await session.SendAsync("password-reset-otp-sent",
                new PasswordResetOtpSentResponse("Ma OTP da duoc gui toi email da dang ky."));
        }
        catch (SmtpException)
        {
            await session.SendAsync("error", new ErrorResponse("Gmail khong gui duoc email. Hay kiem tra EMAIL_USER va EMAIL_APP_PASSWORD."));
        }
        catch (Exception)
        {
            await session.SendAsync("error", new ErrorResponse("Khong the gui OTP luc nay. Hay thu lai sau."));
        }
    }

    private static async Task HandleVerifyPasswordResetAsync(ClientSession session, VerifyPasswordResetRequest? req)
    {
        if (UserStore == null || req == null) return;
        var token = session.PendingPasswordResetToken;
        session.PendingPasswordResetToken = null;
        if (token == null || !OtpTokens.TryValidate(token, req.Otp.Trim(), out var claims) || claims == null)
        {
            await session.SendAsync("error", new ErrorResponse("Ma OTP khong dung hoac da het han."));
            return;
        }

        var result = await UserStore.ChangePasswordAfterOtpAsync(claims.Username, req.NewPassword);
        await session.SendAsync(result.Success ? "password-reset" : "error",
            result.Success ? new SettingsUpdatedResponse(result.Error) : new ErrorResponse(result.Error));
    }

    private static async Task HandleRequestPasswordChangeOtpAsync(ClientSession session)
    {
        if (!session.IsAuthenticated || UserStore == null) return;
        var email = await UserStore.GetEmailAsync(session.Username);
        if (string.IsNullOrWhiteSpace(email))
        {
            await session.SendAsync("error", new ErrorResponse("Tai khoan chua co email de xac nhan."));
            return;
        }
        if (!Email.IsConfigured)
        {
            await session.SendAsync("error", new ErrorResponse("Server chua cau hinh email Gmail."));
            return;
        }

        var otp = RandomNumberGenerator.GetInt32(100000, 1000000).ToString();
        try
        {
            await Email.SendOtpAsync(email, otp);
            session.PendingPasswordChangeToken = OtpTokens.Create(session.Username, email, otp, DateTime.UtcNow.AddMinutes(10));
            await session.SendAsync("password-otp-sent", new PasswordChangeOtpSentResponse("Ma OTP da duoc gui toi email da dang ky."));
        }
        catch (Exception ex)
        {
            await session.SendAsync("error", new ErrorResponse($"Khong gui duoc OTP: {ex.Message}"));
        }
    }

    private static async Task HandleVerifyPasswordChangeAsync(ClientSession session, VerifyPasswordChangeRequest? req)
    {
        if (!session.IsAuthenticated || UserStore == null || req == null) return;
        var token = session.PendingPasswordChangeToken;
        session.PendingPasswordChangeToken = null;
        if (token == null || !OtpTokens.TryValidate(token, req.Otp.Trim(), out var claims) ||
            claims == null || !string.Equals(claims.Username, session.Username, StringComparison.OrdinalIgnoreCase))
        {
            await session.SendAsync("error", new ErrorResponse("Ma OTP khong dung hoac da het han."));
            return;
        }

        var result = await UserStore.ChangePasswordAfterOtpAsync(session.Username, req.NewPassword);
        await session.SendAsync(result.Success ? "settings-updated" : "error",
            result.Success ? new SettingsUpdatedResponse(result.Error) : new ErrorResponse(result.Error));
    }

    private static async Task HandleUpdateAvatarAsync(ClientSession session, UpdateAvatarRequest? req)
    {
        if (!session.IsAuthenticated || UserStore == null || req == null) return;
        if (req.AvatarBase64?.Length > 1_400_000)
        {
            await session.SendAsync("error", new ErrorResponse("Avatar qua lon. Hay chon anh nho hon 1 MB."));
            return;
        }

        var updated = await UserStore.UpdateAvatarAsync(session.Username, req.AvatarBase64);
        await session.SendAsync(updated ? "settings-updated" : "error",
            updated ? new SettingsUpdatedResponse("Cap nhat avatar thanh cong.") : new ErrorResponse("Khong cap nhat duoc avatar."));
    }

    private static async Task HandleUpdateProfileAsync(ClientSession session, UpdateProfileRequest? req)
    {
        if (!session.IsAuthenticated || UserStore == null || req == null) return;
        var result = await UserStore.UpdateProfileAsync(session.Username, req.DisplayName, req.Email, req.Bio, req.Status);
        await session.SendAsync(result.Success ? "settings-updated" : "error",
            result.Success ? new SettingsUpdatedResponse(result.Error) : new ErrorResponse(result.Error));
    }

    private static async Task HandleUpdatePrivacyAsync(ClientSession session, UpdatePrivacyRequest? req)
    {
        if (!session.IsAuthenticated || UserStore == null || req == null) return;
        var updated = await UserStore.UpdatePrivacyAsync(session.Username, req.AllowDirectMessages, req.ShowAvatar, req.ShowOnlineStatus);
        await session.SendAsync(updated ? "settings-updated" : "error",
            updated ? new SettingsUpdatedResponse("Đã cập nhật quyền riêng tư.") : new ErrorResponse("Không thể cập nhật quyền riêng tư."));
    }

    private static async Task HandleBlockUserAsync(ClientSession session, BlockUserRequest? req)
    {
        if (!session.IsAuthenticated || UserStore == null || req == null) return;
        var username = req.Username.Trim();
        if (username.Length == 0 || string.Equals(username, session.Username, StringComparison.OrdinalIgnoreCase))
        {
            await session.SendAsync("error", new ErrorResponse("Tên người dùng không hợp lệ."));
            return;
        }
        if (!await UserStore.ExistsAsync(username))
        {
            await session.SendAsync("error", new ErrorResponse("Người dùng không tồn tại."));
            return;
        }
        var updated = await UserStore.SetBlockedUserAsync(session.Username, username, req.Blocked);
        await session.SendAsync(updated ? "settings-updated" : "error",
            updated ? new SettingsUpdatedResponse(req.Blocked ? "Đã chặn người dùng." : "Đã bỏ chặn người dùng.") : new ErrorResponse("Không thể cập nhật danh sách chặn."));
    }

    private static async Task HandleUpdateAppearanceAsync(ClientSession session, UpdateAppearanceRequest? req)
    {
        if (!session.IsAuthenticated || UserStore == null || req == null) return;
        var updated = await UserStore.UpdateAppearanceAsync(session.Username, req);
        await session.SendAsync(updated ? "settings-updated" : "error",
            updated ? new SettingsUpdatedResponse("Đã lưu giao diện cá nhân.") : new ErrorResponse("Không thể lưu giao diện cá nhân."));
    }

    private static bool IsUserOnline(string username)
    {
        lock (AllClientsLock)
            return AllClients.Any(client => client.IsAuthenticated &&
                string.Equals(client.Username, username, StringComparison.OrdinalIgnoreCase));
    }

    private static async Task HandleJoinAsync(ClientSession session, JoinRequest? req)
    {
        if (!session.IsAuthenticated)
        {
            await session.SendAsync("error", new ErrorResponse("Ban can dang nhap truoc."));
            return;
        }

        var room = (req?.Room ?? "").Trim();
        if (room.Length == 0)
        {
            await session.SendAsync("error", new ErrorResponse("Thieu room."));
            return;
        }

        var previousRoom = session.CurrentRoom;
        var username = session.Username;

        Rooms.CreateRoomIfMissing(room);
        Rooms.Join(session, room);

        // Bao het phong cu la nguoi nay da roi
        if (previousRoom != null && previousRoom != room)
        {
            await Rooms.BroadcastAsync(previousRoom, "system",
                new SystemNotice(previousRoom, $"{username} da roi phong.", DateTimeOffset.Now));
            await Rooms.BroadcastAsync(previousRoom, "online-users",
                new OnlineUsersResponse(previousRoom, Rooms.GetUsernames(previousRoom)));
        }

        // Bao phong moi co nguoi vao
        await Rooms.BroadcastAsync(room, "system",
            new SystemNotice(room, $"{username} da vao phong.", DateTimeOffset.Now), except: session);

        await session.SendAsync("join", new JoinResponse(room, $"Da vao phong {room}."));

        if (MessageStore != null)
        {
            var history = await MessageStore.GetRecentAsync(room);
            UserProfile? viewerProfile = UserStore == null
                ? null
                : await UserStore.GetProfileAsync(session.Username, IsUserOnline(session.Username));
            if (viewerProfile?.ShowAvatar == false)
                history = history.Select(message => message with { AvatarBase64 = null }).ToList();
            await session.SendAsync("history", new HistoryResponse(room, history));
        }

        await Rooms.BroadcastAsync(room, "online-users",
            new OnlineUsersResponse(room, Rooms.GetUsernames(room)));

        await BroadcastRoomListToAllAsync();
    }

    private static async Task HandleCreateRoomAsync(ClientSession session, CreateRoomRequest? req)
    {
        if (!session.IsAuthenticated) return;

        var room = (req?.Room ?? "").Trim();
        if (room.Length == 0)
        {
            await session.SendAsync("error", new ErrorResponse("Ten phong khong duoc rong."));
            return;
        }
        if (Rooms.RoomExists(room))
        {
            await session.SendAsync("error", new ErrorResponse($"Phong '{room}' da ton tai."));
            return;
        }
        Rooms.CreateRoomIfMissing(room);
        await BroadcastRoomListToAllAsync();
    }

    private static async Task HandleChatAsync(ClientSession session, ChatRequest? req)
    {
        if (!session.IsAuthenticated || session.CurrentRoom == null) return;

        var text = (req?.Text ?? "").Trim();
        if (text.Length == 0) return;

        if (text.StartsWith("/ai ", StringComparison.OrdinalIgnoreCase))
        {
            var prompt = text[4..].Trim();
            if (prompt.Length == 0) return;

            string reply;
            try
            {
                reply = await Ai.GenerateAsync(prompt, session.CurrentRoom, session.Username);
            }
            catch (Exception ex)
            {
                reply = $"Khong goi duoc AI service: {ex.Message}";
            }

            var aiMessage = new ChatMessage(Guid.NewGuid().ToString(), session.CurrentRoom, "AI", reply, DateTimeOffset.Now);
            if (MessageStore != null) await MessageStore.SaveAsync(aiMessage);
            await Rooms.BroadcastAsync(session.CurrentRoom, "chat", aiMessage);
            return;
        }

         var userAvatar = string.Empty;
         if (UserStore != null)
         {
             var profile = await UserStore.GetProfileAsync(session.Username, IsUserOnline(session.Username));
             userAvatar = profile?.AvatarBase64 ?? string.Empty;
         }

         var displayName = session.Username;
         if (UserStore != null)
         {
             var profile = await UserStore.GetProfileAsync(session.Username, IsUserOnline(session.Username));
             displayName = string.IsNullOrWhiteSpace(profile?.DisplayName) ? session.Username : profile.DisplayName;
         }

         var chatMessage = new ChatMessage(Guid.NewGuid().ToString(), session.CurrentRoom, session.Username, text, DateTimeOffset.Now,
             AvatarBase64: string.IsNullOrEmpty(userAvatar) ? null : userAvatar,
             DisplayName: displayName);
         if (MessageStore != null) await MessageStore.SaveAsync(chatMessage);
         await BroadcastChatAsync(session.CurrentRoom, chatMessage);
    }

    private static async Task BroadcastChatAsync(string room, ChatMessage message)
    {
        var members = Rooms.GetMembers(room);
        await Task.WhenAll(members.Select(async member =>
        {
            var profile = UserStore == null
                ? null
                : await UserStore.GetProfileAsync(member.Username, IsUserOnline(member.Username));
            var visibleMessage = profile?.ShowAvatar == false
                ? message with { AvatarBase64 = null }
                : message;
            await member.SendAsync("chat", visibleMessage);
        }));
    }

    private static async Task HandleTypingAsync(ClientSession session, TypingRequest? req)
    {
        if (!session.IsAuthenticated || session.CurrentRoom == null) return;

        await Rooms.BroadcastAsync(session.CurrentRoom, "typing",
            new TypingNotice(session.CurrentRoom, session.Username, req?.IsTyping ?? false), except: session);
    }

    private static async Task HandleDirectMessageAsync(ClientSession session, DirectMessageRequest? req)
    {
        if (!session.IsAuthenticated) return;

        var recipient = (req?.To ?? "").Trim();
        var text = (req?.Text ?? "").Trim();
        if (recipient.Length == 0 || text.Length == 0)
        {
            await session.SendAsync("error", new ErrorResponse("Nguoi nhan va noi dung khong duoc rong."));
            return;
        }
        if (string.Equals(recipient, session.Username, StringComparison.OrdinalIgnoreCase))
        {
            await session.SendAsync("error", new ErrorResponse("Khong the gui tin nhan rieng cho chinh minh."));
            return;
        }
        if (UserStore == null || !await UserStore.ExistsAsync(recipient))
        {
            await session.SendAsync("error", new ErrorResponse("Nguoi nhan khong ton tai."));
            return;
        }

        var senderProfile = await UserStore.GetProfileAsync(session.Username, IsUserOnline(session.Username));
        var recipientProfile = await UserStore.GetProfileAsync(recipient, IsUserOnline(recipient));
        if (recipientProfile?.AllowDirectMessages == false ||
            recipientProfile?.BlockedUsers?.Contains(session.Username, StringComparer.OrdinalIgnoreCase) == true ||
            senderProfile?.BlockedUsers?.Contains(recipient, StringComparer.OrdinalIgnoreCase) == true)
        {
            await session.SendAsync("error", new ErrorResponse("Tin nhắn riêng đã bị giới hạn bởi quyền riêng tư."));
            return;
        }

        var message = new DirectMessage(Guid.NewGuid().ToString(), session.Username, recipient, text, DateTimeOffset.Now);
        ClientSession? recipientSession;
        lock (AllClientsLock)
        {
            recipientSession = AllClients.FirstOrDefault(client =>
                client.IsAuthenticated && string.Equals(client.Username, recipient, StringComparison.OrdinalIgnoreCase));
        }

        // Gui ban sao cho nguoi gui de giao dien hien thi ngay sau khi nhan Send.
        await session.SendAsync("direct-message", message);
        if (recipientSession != null)
        {
            await recipientSession.SendAsync("direct-message", message);
        }
        else if (DirectMessageStore != null)
        {
            await DirectMessageStore.SaveAsync(message);
        }
        else
        {
            await session.SendAsync("error", new ErrorResponse("Khong the luu tin nhan offline: MongoDB chua san sang."));
        }
    }

    private static async Task HandleGetUnreadDirectMessagesAsync(ClientSession session)
    {
        if (!session.IsAuthenticated) return;

        var messages = DirectMessageStore == null
            ? new List<DirectMessage>()
            : await DirectMessageStore.TakeUnreadAsync(session.Username);
        await session.SendAsync("unread-direct-messages", new UnreadDirectMessagesResponse(messages));
    }

    private static async Task HandleDisconnectAsync(ClientSession session)
    {
        var room = session.CurrentRoom;
        Rooms.Leave(session);
        lock (AllClientsLock) AllClients.Remove(session);
        session.Close();

        if (room != null && session.Username.Length > 0)
        {
            await Rooms.BroadcastAsync(room, "system",
                new SystemNotice(room, $"{session.Username} da ngat ket noi.", DateTimeOffset.Now));
            await Rooms.BroadcastAsync(room, "online-users",
                new OnlineUsersResponse(room, Rooms.GetUsernames(room)));
        }
        Console.WriteLine($"[-] Client {session.Username} da ngat ket noi.");
        await BroadcastRoomListToAllAsync();
    }

    private static async Task HandleRegisterRequestAsync(ClientSession session, RegisterRequest? req)
    {
        if (UserStore == null)
        {
            await session.SendAsync("error", new ErrorResponse("MongoDB chua san sang."));
            return;
        }

        var username = (req?.Username ?? "").Trim();
        var password = req?.Password ?? "";
        var email = (req?.Email ?? "").Trim();
        if (username.Length < 3 || password.Length < 6 || !email.Contains('@') || !email.Contains('.'))
        {
            await session.SendAsync("error", new ErrorResponse("Vui long nhap username >= 3 ky tu, mat khau >= 6 ky tu va email hop le."));
            return;
        }

        if (!Email.IsConfigured)
        {
            await session.SendAsync("error", new ErrorResponse("Server chua cau hinh EMAIL_USER va EMAIL_APP_PASSWORD."));
            return;
        }

        var otp = RandomNumberGenerator.GetInt32(100000, 1000000).ToString();
        var expiresAtUtc = DateTime.UtcNow.AddMinutes(10);
        Console.WriteLine($"[Register] Nhan yeu cau OTP cho username '{username}', email '{email}'. Chua ghi MongoDB.");
        try
        {
            await Email.SendOtpAsync(email, otp);
            var registrationToken = OtpTokens.Create(username, email, otp, expiresAtUtc);
            session.PendingRegistration = new PendingRegistration(username, password, email, registrationToken);
            Console.WriteLine($"[Register] Da gui OTP cho '{email}'. Dang cho xac nhan.");
            await session.SendAsync("register-otp-sent", new OtpSentResponse("Da gui ma OTP toi email cua ban."));
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[Register] Gui OTP that bai cho '{email}': {ex.Message}");
            await session.SendAsync("error", new ErrorResponse($"Khong gui duoc email OTP: {ex.Message}"));
        }
    }

    private static async Task HandleRegisterVerifyAsync(ClientSession session, VerifyRegistrationRequest? req)
    {
        if (UserStore == null)
        {
            await session.SendAsync("error", new ErrorResponse("MongoDB chua san sang."));
            return;
        }

        var pending = session.PendingRegistration;
        var otp = (req?.Otp ?? "").Trim();
        if (pending == null)
        {
            session.PendingRegistration = null;
            await session.SendAsync("error", new ErrorResponse("Ma OTP da het han. Hay yeu cau dang ky lai."));
            return;
        }
        if (!OtpTokens.TryValidate(pending.RegistrationToken, otp, out var claims) ||
            claims == null || !string.Equals(claims.Username, pending.Username, StringComparison.Ordinal) ||
            !string.Equals(claims.Email, pending.Email, StringComparison.OrdinalIgnoreCase))
        {
            await session.SendAsync("error", new ErrorResponse("Ma OTP khong dung hoac da het han."));
            return;
        }

        var result = await UserStore.RegisterAsync(pending.Username, pending.Password, pending.Email);
        session.PendingRegistration = null;
        if (!result.Success)
        {
            await session.SendAsync("error", new ErrorResponse(result.Error));
            return;
        }

        session.Username = pending.Username;
        session.IsAuthenticated = true;
        Console.WriteLine($"[Register] Da xac nhan OTP va ghi user '{pending.Username}' vao MongoDB.");
        await session.SendAsync("auth", new AuthResponse(pending.Username, result.Error));
    }

    private static async Task HandleLoginAsync(ClientSession session, AuthRequest? req)
    {
        if (UserStore == null)
        {
            await session.SendAsync("error", new ErrorResponse("MongoDB chua san sang."));
            return;
        }

        var username = (req?.Username ?? "").Trim();
        if (!await UserStore.ValidateLoginAsync(username, req?.Password ?? ""))
        {
            await session.SendAsync("error", new ErrorResponse("Username hoac mat khau khong dung."));
            return;
        }

        // Check if 2FA is enabled
        var twoFactorEnabled = await UserStore.IsTwoFactorEnabledAsync(username);
        if (twoFactorEnabled)
        {
            // Send 2FA challenge
            session.Username = username;
            session.IsAuthenticated = false; // Not fully authenticated until 2FA
            await session.SendAsync("2fa-required", new TwoFactorVerifyResponse(false, "Vui lòng nhập mã xác thực 2FA."));
            return;
        }

        // No 2FA required, complete login
        await CompleteLoginAsync(session, username);
    }

    private static async Task CompleteLoginAsync(ClientSession session, string username)
    {
        if (UserStore == null) return;

        session.Username = username;
        session.IsAuthenticated = true;
        session.TwoFactorVerified = true;
        session.LoginTime = DateTime.UtcNow;
        session.LastActive = DateTime.UtcNow;

        // Add session to user's session list
        var userSession = new UserSession
        {
            SessionId = session.SessionId,
            DeviceInfo = session.DeviceInfo,
            IpAddress = session.IpAddress,
            LoginTime = session.LoginTime,
            LastActive = session.LastActive
        };
        await UserStore.AddSessionAsync(username, userSession);

        // Add login history
        var loginEntry = new LoginHistoryEntry
        {
            LoginTime = session.LoginTime,
            IpAddress = session.IpAddress,
            DeviceInfo = session.DeviceInfo,
            Success = true
        };
        await UserStore.AddLoginHistoryAsync(username, loginEntry);

        await session.SendAsync("auth", new AuthResponse(username, "Dang nhap thanh cong."));
    }

    private static async Task HandleTwoFactorVerifyAsync(ClientSession session, TwoFactorVerifyRequest? req)
    {
        if (UserStore == null || req == null || string.IsNullOrEmpty(session.Username)) return;

        var username = session.Username;
        var code = req.Code.Trim();

        if (await UserStore.VerifyTwoFactorAsync(username, code))
        {
            await CompleteLoginAsync(session, username);
        }
        else
        {
            await session.SendAsync("2fa-verify", new TwoFactorVerifyResponse(false, "Mã xác thực không đúng."));
        }
    }

    // Session management handlers
    private static async Task HandleGetSessionsAsync(ClientSession session)
    {
        if (!session.IsAuthenticated || UserStore == null) return;

        var sessions = await UserStore.GetSessionsAsync(session.Username);
        var sessionInfos = sessions.Select(s => new SessionInfo(
            s.SessionId,
            s.DeviceInfo,
            s.IpAddress,
            new DateTimeOffset(s.LoginTime, TimeSpan.Zero),
            new DateTimeOffset(s.LastActive, TimeSpan.Zero),
            s.SessionId == session.SessionId
        )).ToList();

        await session.SendAsync("sessions", new GetSessionsResponse(sessionInfos));
    }

    private static async Task HandleRevokeSessionAsync(ClientSession session, RevokeSessionRequest? req)
    {
        if (!session.IsAuthenticated || UserStore == null || req == null) return;

        // Don't allow revoking current session through this endpoint
        if (req.SessionId == session.SessionId)
        {
            await session.SendAsync("session-revoked", new RevokeSessionResponse(false, "Không thể thu hồi phiên hiện tại. Hãy dùng 'Đăng xuất khỏi tất cả thiết bị'."));
            return;
        }

        await UserStore.RemoveSessionAsync(session.Username, req.SessionId);

        // Also disconnect the session if it's currently connected
        ClientSession? targetSession;
        lock (AllClientsLock)
        {
            targetSession = AllClients.FirstOrDefault(c => c.SessionId == req.SessionId && c.IsAuthenticated);
        }

        if (targetSession != null)
        {
            await targetSession.SendAsync("session-revoked", new RevokeSessionResponse(true, "Phiên đăng nhập đã bị thu hồi."));
            targetSession.Close();
        }

        await session.SendAsync("session-revoked", new RevokeSessionResponse(true, "Đã thu hồi phiên đăng nhập."));
    }

    private static async Task HandleRevokeAllSessionsAsync(ClientSession session)
    {
        if (!session.IsAuthenticated || UserStore == null) return;

        // Keep current session, revoke all others
        await UserStore.RemoveAllSessionsAsync(session.Username, session.SessionId);

        // Disconnect all other sessions
        List<ClientSession> otherSessions;
        lock (AllClientsLock)
        {
            otherSessions = AllClients
                .Where(c => c.IsAuthenticated && 
                    string.Equals(c.Username, session.Username, StringComparison.OrdinalIgnoreCase) &&
                    c.SessionId != session.SessionId)
                .ToList();
        }

        foreach (var otherSession in otherSessions)
        {
            await otherSession.SendAsync("session-revoked", new RevokeSessionResponse(true, "Phiên đăng nhập đã bị thu hồi bởi người dùng."));
            otherSession.Close();
        }

        await session.SendAsync("all-sessions-revoked", new RevokeAllSessionsResponse(true, "Đã đăng xuất khỏi tất cả thiết bị khác."));
    }

    // Two-factor authentication handlers
    private static async Task HandleTwoFactorSetupAsync(ClientSession session)
    {
        if (!session.IsAuthenticated || UserStore == null) return;

        var result = await UserStore.SetupTwoFactorAsync(session.Username);
        if (!result.Success)
        {
            await session.SendAsync("2fa-setup", new TwoFactorSetupResponse("", "", new List<string>()));
            return;
        }

        // Generate QR code (base64 encoded PNG)
        var qrCodeBase64 = GenerateQrCodeBase64($"otpauth://totp/ChatNet:{session.Username}?secret={result.Secret}&issuer=ChatNet");

        await session.SendAsync("2fa-setup", new TwoFactorSetupResponse(result.Secret!, qrCodeBase64, result.BackupCodes!));
    }

    private static async Task HandleTwoFactorEnableAsync(ClientSession session, TwoFactorEnableRequest? req)
    {
        if (!session.IsAuthenticated || UserStore == null || req == null) return;

        var result = await UserStore.EnableTwoFactorAsync(session.Username, req.Code.Trim());
        await session.SendAsync("2fa-enabled", new TwoFactorEnableResponse(result.Success, result.Message, result.BackupCodes));
    }

    private static async Task HandleTwoFactorDisableAsync(ClientSession session, TwoFactorDisableRequest? req)
    {
        if (!session.IsAuthenticated || UserStore == null || req == null) return;

        var result = await UserStore.DisableTwoFactorAsync(session.Username, req.Code.Trim());
        await session.SendAsync("2fa-disabled", new TwoFactorDisableResponse(result.Success, result.Message));
    }

    private static async Task HandleTwoFactorStatusAsync(ClientSession session)
    {
        if (!session.IsAuthenticated || UserStore == null) return;

        var enabled = await UserStore.IsTwoFactorEnabledAsync(session.Username);
        await session.SendAsync("2fa-status", new TwoFactorStatusResponse(enabled));
    }

    // Login history handler
    private static async Task HandleGetLoginHistoryAsync(ClientSession session)
    {
        if (!session.IsAuthenticated || UserStore == null) return;

        var history = await UserStore.GetLoginHistoryAsync(session.Username);
        var historyEntries = history.Select(h => new LoginHistoryEntryResponse(
            h.LoginTime,
            h.IpAddress,
            h.DeviceInfo,
            h.Success
        )).ToList();

        await session.SendAsync("login-history", new GetLoginHistoryResponse(historyEntries));
    }

    private static async Task BroadcastRoomListToAllAsync()
    {
        List<ClientSession> clients;
        lock (AllClientsLock)
        {
            clients = AllClients.Where(client => client.IsAuthenticated).ToList();
        }

        var response = new RoomListResponse(Rooms.GetRoomList());
        await Task.WhenAll(clients.Select(client => client.SendAsync("room-list", response)));
    }

    private static string GenerateQrCodeBase64(string text)
    {
        using var generator = new QRCodeGenerator();
        using var data = generator.CreateQrCode(text, QRCodeGenerator.ECCLevel.Q);
        var qrCode = new PngByteQRCode(data);
        return Convert.ToBase64String(qrCode.GetGraphic(10));
    }
}
